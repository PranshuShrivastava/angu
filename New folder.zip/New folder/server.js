// Get dependencies
const express = require('express');
const http = require('http');
const path = require('path');
const bodyParser = require('body-parser');

// Require for Unique Identifier
const { v4: uuidv4 } = require('uuid');

const dotenv = require("dotenv");
dotenv.config();
const cors = require("cors");
const BitlyClient = require('bitly').BitlyClient;
const bitly = new BitlyClient('0198565083fec7ba38e0b21dcf783a23deb31981');
var moment = require('moment');
const axios = require('axios');


const jwt_decode = require('jwt-decode');

var _ = require('underscore');
const request = require('request');

// Log4js for maintaining logs
const log4js = require('log4js')

// Logger Configuration
log4js.configure({
    appenders: { fileAppender: { type: 'file', filename: './logs/tracing.log' } },
    categories: { default: { appenders: ['fileAppender'], level: 'info' } }
});
// Create a logger
const logger = log4js.getLogger();


// JSON WEB TOKEN Generation
const { sign } = require("jsonwebtoken")

// Validating the Web Token
const { checktoken } = require('./auth/token_validation')

const app = express();
app.use(express.static('Files'));

app.use(cors());

// app.use(function (req, res, next) {
//     res.header("Access-Control-Allow-Origin", "*");
//     res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
//     next();
// });



// Parsers for POST data
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

// Point static path to dist
app.use('/bot', express.static(path.join(__dirname, '/dist/wa-bot/')));

// Catch all other routes and return the index file
app.get('/bot/share-location/:id/:token', (req, res) => {
    res.sendFile(path.join(__dirname, '/dist/wa-bot/index.html'));
});

app.get('/bot/graphs/:MobileNumber/:WeekNo/:token', (req, res) => {
    res.sendFile(path.join(__dirname, '/dist/wa-bot/index.html'));
});

app.get('/bot/download-pdf/:id/:token', (req, res) => {
    res.sendFile(path.join(__dirname, '/dist/wa-bot/index.html'));
});
app.get('/bot/Ebrochure', (req, res) => {
    res.sendFile(path.join(__dirname, '/dist/wa-bot/assets/Ebrochure.pdf'));
});


const mysqlConenction = require('./mysqlCon');

//const pool = require('./db')

const { parse } = require('path');

mysqlConenction.connect((err) => {
    if (!err)
        console.log('DB connected succeeded.')
    else
        console.log('DB connectionion failed. \n Error :' + JSON.stringify(err, undefined, 2));
});


/**
 * Get port from environment and store in Express.
 */
const port = process.env.PORT || '3000';

app.set('port', port);

/**
 * Create HTTP server.
 */
const server = http.createServer(app);

/**
 * Listen on provided port, on all network interfaces.
 */
server.listen(port, () => console.log(`Angular app running on localhost:${port}`));




/**
 * Main URL for API Calling
 */
app.get('/api', (req, res) => {
    InsertOptIn();
    res.send(
        `<h1 style='text-align: center'>
          Welcome to VF WABusiness Integration
          <br><br>
          <b style="font-size: 182px;">📱✔</b>
      </h1>`
    );
})


// Calling Bot from BotPress
function GetBotPressMsg(Body, _From, _To) {
    var BotPressURL = process.env.BotPressURL
    const options = {
        url: `${BotPressURL}v1/bots/eicher-bot2/converse/${_From}`, // eicher-bot2 is Bot ID from botpress
        json: {
            "type": "text",
            "text": String(Body)
        }
    };
    request.post(options, (err, res, body) => {
        if (err) {
            logger.error('BotPress reponse error:' + err.Message)
            return console.log(err);
        }
        var i;
        for (i = 0; i < body.responses.length; i++) {
            logger.info('BotPress reponse on success:' + body.responses[i].text + ', to :' + _From + ' , From :' + _To)
            SendMsg(body.responses[i].text, _From, _To)
        }
    });

}

// Getting location details from Heremap using lat and long
function FetchLocationFromLatLong(lat, long) {
    var HeremapFetchLocationURL = process.env.HeremapFetchLocationURL
    const options = {
        url: `${HeremapFetchLocationURL}reversegeocode.json?prox=${lat},${long},150&mode=retrieveAreas&gen=9&app_id=zJpOdSGeTiXA8hNWqi3T&app_code=Jw1dV73izeei8Gx0r1PNPQ`,
    };
    return new Promise(function (resolve, reject) {
        // Do async job
        request.get(options, function (err, resp, body) {
            if (err) {
                logger.info('location could not be fetched whiling getting Location from HereMap using lat :' + lat + ',long ' + long)
                resolve('location could not be fetched');
            } else {
                var resData = JSON.parse(resp.body)
                var location;
                if (resData.Response != undefined) {
                    location = resData.Response.View[0].Result[0].Location.Address.Label
                }
                resolve(location);
            }
        })
    })
}


// Value First Inbound port to send WA Messages
app.post('/api/inbound', (req, res) => {
    console.log(req.query.text)
    let _To = req.query.to;
    let _From = req.query.from;

    // Log a message
    logger.info('Inbound request with followed details :' + JSON.stringify('to :' + req.query.to + ' From :' + req.query.from + ' Message :' + req.query.text + ',' + req.query.longitude + ',' + req.query.latitude))

    var LocationDetail
    if (req.query.text != '$Text') {
        let Body = req.query.text;
        GetBotPressMsg(Body.trim(), _From, _To)
    }
    else {
        var initializePromise = FetchLocationFromLatLong(req.query.latitude, req.query.longitude);
        initializePromise.then(function (result) {

            // Log a message
            logger.info('Get Location Address : ' + result)
            console.log(result);
            LocationDetail = result
            let Body.trim() = req.query.longitude + '_' + req.query.latitude + '_' + LocationDetail
            GetBotPressMsg(Body, _From, _To)
        })
    }

    res.send(
        'Okay'
    );
    res.end();
})

function SendMsg(Body, From, To) {
    var ValueFirstURL = process.env.ValueFirstURL
    const options = {
        url: `${ValueFirstURL}`,
        form: {
            data: `<?xml version="1.0" encoding="ISO-8859-1"?>
          <!DOCTYPE MESSAGE SYSTEM "http://127.0.0.1:80/psms/dtd/messagev12.dtd">
          <MESSAGE VER="1.2">
          <USER USERNAME="${process.env.WhatsAppUserID}" PASSWORD="${process.env.WhatsAppPassword}" />
          <SMS  UDH="0" CODING="1" TEXT="${Body}" PROPERTY="0" ID="1" TEMPLATE="" EMAILTEXT="" ATTACHMENT="">
          <ADDRESS FROM="${To}" TO="${From}" EMAIL="" SEQ="1" TAG="some clientside random data"/>
          </SMS> 
          </MESSAGE>`,
            action: 'send'
        }
    };
    request.post(options, (err, res, body) => {
        if (err) {
            logger.error('VF send WhatsApp on Error:' + err.Message)
            return console.log(err);
        }
        else {
            logger.info('VF WhatsApp message Body Data :' + options.form.data)
            logger.info('VF send WhatsApp message on success:' + JSON.stringify(body))
        }
    });

}

// Generate Link for share location with Time and userid with Bitly
app.post("/api/EOSLinkInsert", async (req, res) => {
    try {
        // Read Body from API call
        var VehicleDetails = req.body;

        // Generate the JSON Web Token for validating the link at angular App end
        let JWTData = [{
            MobileNumber: VehicleDetails.MobileNumber
        }]

        const jsontoken = sign({ result: JWTData }, process.env.ACCESS_TOKEN_SECRET, {
            expiresIn: process.env.ACCESS_TOKEN_SECRET_TIMOUT
        })


        var AngularAppURL = process.env.AngularAppURL
        var URL = `${AngularAppURL}share-location/`
        console.log(URL)
        var GenerationTime = moment().format('DD-MM-YY HH:mm:ss');

        var MobileNumber = VehicleDetails.MobileNumber

        // Link Generate Time Mobile Number of WA User and JWT
        let originalString = GenerationTime + ',' + MobileNumber + '/' + jsontoken;
        URL = URL + originalString

        // Log a message
        logger.info('generating Token from  EOSLinkInsert :' + URL)


        bitly
            .shorten(URL)
            .then(function (result) {
                // Log a message 
                dataResult = ([{ Status: 'Succeeded', ShortLink: result.link }])
                console.log(result);
                res.send(dataResult);
                res.end();
            })
            .catch(function (error) {
                logger.error('EOS Link Generation on Error:' + error.Message)
                console.error(error);
            });
    } catch (error) {
        logger.error('EOS Link Generation on catch Error:' + error.Message)
        console.log(error)
        res.json(error);
    }
})

/**
 * Get the Location from Angular End and send it using WA with customer Mobile (Session)
 * Validating the JSON Web Token with checktoken
 */

app.post("/api/EOSDataUpdate", checktoken, async (req, res) => {
    try {
        var VehicleDetails = req.body;
        var FData = decodeURIComponent(VehicleDetails.Key)
        var DateAndNumber = FData.split(',');
        GetBotPressMsg('Location'.concat('_', VehicleDetails.BreakdownLattitude, '_', VehicleDetails.BreakdownLongitude, '_', VehicleDetails.BreakdownLocation), '91' + DateAndNumber[1], process.env.WhatsAppUserID)
        res.json([{ Status: "Succeeded", Message: "Data has been updated." }])
    } catch (error) {
        logger.error('EOS Data Update on catch Error:' + error.Message)
        console.log(error)
    }
})



// Create PDF link by passsing the Service invoice Number
app.post("/api/PdfLinkGeneration", async (req, res) => {
    try {

        // Read Body from API call
        var ServiceInvoice = req.body;

        // Generate the JSON Web Token for validating the link at angular App end
        let JWTData = [{
            ServiceInvoiceJCNo: ServiceInvoice.ServiceInvoiceJCNo
        }]

        const jsontoken = sign({ result: JWTData }, process.env.ACCESS_TOKEN_SECRET, {
            expiresIn: process.env.ACCESS_TOKEN_SECRET_TIMOUT
        })

        var AngularAppURL = process.env.AngularAppURL
        var URL = `${AngularAppURL}download-pdf/`
        console.log(URL)

        URL = URL + ServiceInvoice.ServiceInvoiceJCNo + '/' + jsontoken
        bitly
            .shorten(URL)
            .then(function (result) {
                console.log(result)
                dataResult = ([{ Status: 'Succeeded', ShortLink: result.link }])
                res.send(dataResult);
                res.end();
            })
            .catch(function (error) {
                logger.error('Pdf Link Generation on Error:' + error.Message)
                console.error(error);
            });
    } catch (error) {
        logger.error('Pdf Link Generation on catch Error:' + error.Message)
        console.log(error)
        res.json(error);
    }
})


/**
 * Fetch PDF Data from VE API and send it to angular end to generate PDF
 * Validating the JWT Token
 */
app.post("/api/FetchPDFDataFromVE", checktoken, async (req, res) => {
    try {
        let Details = req.body;
        var InvoiceNumber = Details.InvoiceNumber //4000003512
        const username = 'UPTIMEUSR1'
        const password = 'data@1234'
        const token = Buffer.from(`${username}:${password}`, 'utf8').toString('base64')

        var InvoicePDFDataURL = process.env.InvoicePDFDataURL
        let result = await axios.get(
            `${InvoicePDFDataURL}opu/odata/sap/ZAPI_TEL_DETAILS_SRV/in_tel_formSet('${InvoiceNumber}')/$value`,
            {
                headers: {
                    Authorization: `Basic ${token}`
                }
            }
        )
        console.log(`${InvoicePDFDataURL}opu/odata/sap/ZAPI_TEL_DETAILS_SRV/in_tel_formSet('${InvoiceNumber}')/$value`)
        dataResult = ([{ Status: 'Succeeded', PdfDData: result.data }])
        res.send(dataResult);

    } catch (err) {
        logger.error('Fetch PDF Data From VE on catch Error :' + err.Message)
        console.log(err)
    }
    res.end();
})


// Create Fleet Dashboard Link by passing Mobile Number and Week No
app.post("/api/fleetdashboardlinkGeneration", async (req, res) => {
    try {
        // Read Body from API call
        var Details = req.body;

        // Generate the JSON Web Token for validating the link at angular App end
        let JWTData = [{
            MobileNumber: Details.MobileNumber
        }]

        const jsontoken = sign({ result: JWTData }, process.env.ACCESS_TOKEN_SECRET, {
            expiresIn: process.env.ACCESS_TOKEN_SECRET_TIMOUT
        })



        var AngularAppURL = process.env.AngularAppURL
        var URL = `${AngularAppURL}graphs/`

        URL = URL + Details.MobileNumber + '/' + Details.WeekNo + '/' + jsontoken
        logger.info('Creating Bitly link for fleet dashboard :' + URL)
        bitly
            .shorten(URL)
            .then(function (result) {
                console.log(result)
                dataResult = ([{ Status: 'Succeeded', ShortLink: result.link }])
                res.send(dataResult);
                res.end();
            })
            .catch(function (error) {
                logger.error('Pdf Link Generation on Error:' + error.Message)
                console.error(error);
            });
    } catch (error) {
        logger.error('Fleet Dashboard Link Generation on catch Error:' + error.Message)
        console.log(error)
        res.json(error);
    }
})

/**
 * FETCH CUSTOMER FLEET DAHSBOARD REPORT
 * Validating the JWT
 */
app.post('/api/FetchDashboardData', checktoken, (req, res) => {

    let user = req.body;
    var MobileNumber = user.MobileNumber
    var WeekNo = user.WeekNo
    mysqlConenction.query(`CALL protech.sp_WACustWeeklySummary(${MobileNumber},${WeekNo});`, function (err, result) {
        if (!err) {
            var Data = result[0]
            var filtered = Data.filter(a => a.Rec_Type == 0);
            var ModalBases = []
            ModalBases.push(_.groupBy(filtered, 'VehModel'))
            let Dataa = Object.keys(ModalBases[0]).length;
            let Keys = Object.keys(ModalBases[0]);


            // Fuel Efficiency Score
            let FEArray = [];
            let FESubArray = [];
            let FESubWArray = [];
            for (i = 0; i < Dataa; i++) {
                for (j = 0; j < ModalBases[0][Keys[i]].length; j++) {
                    // console.log(ModalBases[0][Keys[i]])
                    FESubArray.push(ModalBases[0][Keys[i]][j].FE)
                    FESubWArray.push(ModalBases[0][Keys[i]][j].WeekNo)
                }
            }
            FEArray.push([{ main: { data: FESubArray, xAxis: FESubWArray }, "headerName": "Fuel Efficiency Score", "modelName": "Model 1" }])


            // % Cruise control usage 
            let PCCUSubArray = [];
            let PCCUSubWArray = [];
            for (i = 0; i < Dataa; i++) {
                for (j = 0; j < ModalBases[0][Keys[i]].length; j++) {
                    //console.log(ModalBases[0][Keys[i]])
                    PCCUSubArray.push(ModalBases[0][Keys[i]][j].PerCruiseUsg)
                    PCCUSubWArray.push(ModalBases[0][Keys[i]][j].WeekNo)
                }
            }
            FEArray.push([{ main: { data: PCCUSubArray, xAxis: PCCUSubWArray }, "headerName": "% Cruise control usage", "modelName": "Model 1" }])



            // Sweetspot score
            let SSSubArray = [];
            let SSSubWArray = [];
            for (i = 0; i < Dataa; i++) {
                for (j = 0; j < ModalBases[0][Keys[i]].length; j++) {
                    // console.log(ModalBases[0][Keys[i]])
                    SSSubArray.push(ModalBases[0][Keys[i]][j].PerSSUsg)
                    SSSubWArray.push(ModalBases[0][Keys[i]][j].WeekNo)
                }
            }
            FEArray.push([{ main: { data: SSSubArray, xAxis: SSSubWArray }, "headerName": "Sweetspot Score", "modelName": "Model 1" }])



            // %Idle Time > 10 min
            let IdeaTIme10MinSubArray = [];
            let IdeaTIme10MinSubWArray = [];
            for (i = 0; i < Dataa; i++) {
                for (j = 0; j < ModalBases[0][Keys[i]].length; j++) {
                    // console.log(ModalBases[0][Keys[i]])
                    IdeaTIme10MinSubArray.push(ModalBases[0][Keys[i]][j].PerCruiseUsg)
                    IdeaTIme10MinSubWArray.push(ModalBases[0][Keys[i]][j].WeekNo)
                }
            }
            FEArray.push([{ main: { data: IdeaTIme10MinSubArray, xAxis: IdeaTIme10MinSubWArray }, "headerName": "%Idle Time > 10 min", "modelName": "Model 1" }])


            // Harsh Acceleration
            let HAUsgSubArray = [];
            let HAUsgSubWArray = [];
            for (i = 0; i < Dataa; i++) {
                for (j = 0; j < ModalBases[0][Keys[i]].length; j++) {
                    // console.log(ModalBases[0][Keys[i]])
                    HAUsgSubArray.push(ModalBases[0][Keys[i]][j].HAUsg)
                    HAUsgSubWArray.push(ModalBases[0][Keys[i]][j].WeekNo)
                }
            }
            FEArray.push([{ main: { data: HAUsgSubArray, xAxis: HAUsgSubWArray }, "headerName": "Harsh Acceleration", "modelName": "Model 1" }])


            // Harsh Braking
            let HBUsgSubWArray = [];
            let HBUsgSubArray = [];
            for (i = 0; i < Dataa; i++) {
                for (j = 0; j < ModalBases[0][Keys[i]].length; j++) {
                    // console.log(ModalBases[0][Keys[i]])
                    HBUsgSubArray.push(ModalBases[0][Keys[i]][j].HBUsg)
                    HBUsgSubWArray.push(ModalBases[0][Keys[i]][j].WeekNo)
                }
            }
            FEArray.push([{ main: { data: HBUsgSubArray, xAxis: HBUsgSubWArray }, "headerName": "Harsh Braking", "modelName": "Model 1" }])


            // Avg. Drive hours/vehicle/day
            let AvgDriveHrsSubWArray = [];
            let AvgDriveHrsSubArray = [];
            for (i = 0; i < Dataa; i++) {
                for (j = 0; j < ModalBases[0][Keys[i]].length; j++) {
                    // console.log(ModalBases[0][Keys[i]])
                    AvgDriveHrsSubArray.push(ModalBases[0][Keys[i]][j].AvgDriveHrs)
                    AvgDriveHrsSubWArray.push(ModalBases[0][Keys[i]][j].WeekNo)
                }
            }
            FEArray.push([{ main: { data: AvgDriveHrsSubArray, xAxis: AvgDriveHrsSubWArray }, "headerName": "Avg. Drive hours/vehicle/day", "modelName": "Model 1" }])



            // % Time spent in >70 Km/hr
            let PerTimeOSgt70SubWArray = [];
            let PerTimeOSgt70SubArray = [];
            for (i = 0; i < Dataa; i++) {
                for (j = 0; j < ModalBases[0][Keys[i]].length; j++) {
                    // console.log(ModalBases[0][Keys[i]])
                    PerTimeOSgt70SubArray.push(ModalBases[0][Keys[i]][j].PerTimeOSgt70)
                    PerTimeOSgt70SubWArray.push(ModalBases[0][Keys[i]][j].WeekNo)
                }
            }
            FEArray.push([{ main: { data: PerTimeOSgt70SubArray, xAxis: PerTimeOSgt70SubWArray }, "headerName": "% Time spent in >70 Km/hr", "modelName": "Model 1" }])


            // % Night Driving
            let PerNightDriveHrsSubWArray = [];
            let PerNightDriveHrsSubArray = [];
            for (i = 0; i < Dataa; i++) {
                for (j = 0; j < ModalBases[0][Keys[i]].length; j++) {
                    // console.log(ModalBases[0][Keys[i]])
                    PerNightDriveHrsSubWArray.push(ModalBases[0][Keys[i]][j].PerNightDriveHrs)
                    PerNightDriveHrsSubArray.push(ModalBases[0][Keys[i]][j].WeekNo)
                }
            }
            FEArray.push([{ main: { data: PerNightDriveHrsSubArray, xAxis: PerNightDriveHrsSubWArray }, "headerName": "% Night Driving", "modelName": "Model 1" }])


            // Non Stop Driving Instances
            let NonStopDriveCntSubWArray = [];
            let NonStopDriveCntSubArray = [];
            for (i = 0; i < Dataa; i++) {
                for (j = 0; j < ModalBases[0][Keys[i]].length; j++) {
                    // console.log(ModalBases[0][Keys[i]])
                    NonStopDriveCntSubArray.push(ModalBases[0][Keys[i]][j].NonStopDriveCnt)
                    NonStopDriveCntSubWArray.push(ModalBases[0][Keys[i]][j].WeekNo)
                }
            }
            FEArray.push([{ main: { data: NonStopDriveCntSubArray, xAxis: NonStopDriveCntSubWArray }, "headerName": "Non Stop Driving Instances", "modelName": "Model 1" }])


            // Non Stop Driving Instances
            let OverStoppageSubWArray = [];
            let OverStoppageSubArray = [];
            for (i = 0; i < Dataa; i++) {
                for (j = 0; j < ModalBases[0][Keys[i]].length; j++) {
                    // console.log(ModalBases[0][Keys[i]])
                    OverStoppageSubArray.push(ModalBases[0][Keys[i]][j].OverStoppage)
                    OverStoppageSubWArray.push(ModalBases[0][Keys[i]][j].WeekNo)
                }
            }
            FEArray.push([{ main: { data: OverStoppageSubArray, xAxis: OverStoppageSubWArray }, "headerName": "Non Stop Driving Instances", "modelName": "Model 1" }])


            //  //Reaction to DIY Cases
            //  let OverStoppageSubWArray = [];
            //  let OverStoppageSubArray = [];
            //  for (i = 0; i < Dataa; i++) {
            //      for (j = 0; j < ModalBases[0][Keys[i]].length; j++) {
            //          //console.log(ModalBases[0][Keys[i]])
            //          OverStoppageSubArray.push(ModalBases[0][Keys[i]][j].OverStoppage)
            //          OverStoppageSubWArray.push(ModalBases[0][Keys[i]][j].WeekNo)
            //      }
            //  }
            //  FEArray.push([{ main: { data: OverStoppageSubArray, xAxis: OverStoppageSubWArray   }, "headerName": "Reaction to DIY Cases", "modelName": "Model 1" }])


            //   //Reaction to Stop Now
            // let OverStoppageSubWArray = [];
            // let OverStoppageSubArray = [];
            // for (i = 0; i < Dataa; i++) {
            //     for (j = 0; j < ModalBases[0][Keys[i]].length; j++) {
            //         //console.log(ModalBases[0][Keys[i]])
            //         OverStoppageSubArray.push(ModalBases[0][Keys[i]][j].OverStoppage)
            //         OverStoppageSubWArray.push(ModalBases[0][Keys[i]][j].WeekNo)
            //     }
            // }
            // FEArray.push([{ main: { data: OverStoppageSubArray, xAxis: OverStoppageSubWArray   }, "headerName": "Reaction to Stop Now", "modelName": "Model 1" }])




            console.log(FEArray)
            res.send(FEArray)
        }
        else {
            console.log(err);
            logger.error('Genrating Graphs Data From VE on catch Error :' + err.Message)
            res.json([{ Status: 'Error', Message: err.sqlMessage }])
        }
    });
})


/**
 * OptIn Customer Data Save

app.post("/bot/api/InsertOptInCustomer", (req, res) => {
    try {
        let Details = req.body;
        var uuid = uuidv4();
        console.log(Details)

        // Save Log for Incoming OptIn User
        logger.info('OptIn Customer Incoming:' + JSON.stringify(Details))

        var IsExistsResult = IsUserExists(Details.mobile_number)
        IsExistsResult.then(function (result) {
            if (result == 'Not Exists') {
                pool.query(`INSERT INTO public.customer_optin( "id", "customer_name", "subscription_mode", "subscribed_on", "mobile_number")
        VALUES ($1,$2,$3,now(),$4)  RETURNING *`, [uuid, Details.customer_name, Details.subscription_mode, Details.mobile_number], (error, results) => {
                    if (error) {
                        return 'error'
                    }
                    else {
                        res.status(201).send([{
                            Status: 'Succeeded', Message: `User added with Mobile Number : ${results.rows[0].mobile_number}`
                        }])
                    }
                })
            }
            else if (result != 'error') {
                res.status(409).send([{
                    Status: 'Warning', Message: `User already exists with Mobile Number : ${Details.mobile_number}`
                }])
            }
            else {
                res.send([{
                    Status: 'Error', Message: `Error Occured while getting status of User`
                }])
            }
        })

    } catch (error) {
        console.log(error)
        // Save Log for Incoming OptIn User
        logger.error('OptIn Customer insert error:' + JSON.stringify(error))
        res.json([{ Status: 'Error', Message: error.message }])
    }
})
 */

/**
 * OptIn Customer Data Save

app.post("/bot/api/UnSubOptInCustomer", async (req, res) => {
    try {
        let now = moment().format("YYYY-MM-DD HH:mm:ss");
        console.log(now)

        let Details = req.body;
        console.log(Details)
        // Save Log for Incoming OptIn User
        logger.info('OptIn Customer Unsub:' + JSON.stringify(Details))
        const newTodo = await pool.query(`UPDATE public.customer_optin
        SET  unsubscribed_on = $1, isactive = false
        WHERE mobile_number =$2 and isactive = true;`,
            [now, Details.mobile_number]
        );

        res.status(201).send([{
            Status: 'Succeeded', Message: `User Unsubscribed with Mobile Number: ${Details.mobile_number}`
        }])

    } catch (error) {
        console.log(error)
        // Save Log for Incoming OptIn User
        logger.error('OptIn Customer Unsub error:' + JSON.stringify(error))
        res.json([{ Status: 'Error', Message: error.message, Code: error }])
    }
})
 

function IsUserExists(MobileNumber) {
    try {
        return new Promise(function (resolve, reject) {
            setTimeout(function () {
                console.log(MobileNumber)
                pool.query('SELECT id FROM public.customer_optin WHERE mobile_number = $1 and isactive=true', [MobileNumber], (error, results) => {
                    if (error) {
                        logger.error('Error while getting status user exists or not :' + error.message)
                        resolve(error.message);
                    }
                    else {
                        if (results.rows.length > 0) {
                            resolve(results.rows[0].id);
                        } else {
                            resolve('Not Exists');
                        }
                    }
                })

            }, 1800);
        })
    }
    catch (error) {
        console.log(error)
        // Save Log for Incoming OptIn User
        logger.error('OptIn Customer Unsub error:' + JSON.stringify(error))
        res.json([{ Status: 'Error', Message: error.message, Code: error }])
    }
}

 */

/**
 * OptIn Customer Data Save
 */
app.post("/bot/api/GenerateToken", (req, res) => {
    try {

        // Read Body from API call
        var Details = req.body;

        // Generate the JSON Web Token for validating the link at angular App end
        let JWTData = Details

        const jsontoken = sign({ result: JWTData }, process.env.ACCESS_TOKEN_SECRET, {
            expiresIn: process.env.GENERATE_TOKEN_TIMEOUT
        })
        dataResult = ([{ Status: 'Succeeded', Token: jsontoken }])
        console.log(dataResult);
        res.send(dataResult);
        res.end();

    } catch (error) {
        console.log(error)
        // Save Log for Incoming OptIn User
        logger.error('OptIn Customer insert error:' + JSON.stringify(error))
        res.json([{ Status: 'Error', Message: error.message }])
    }
})
const { verify} = require("jsonwebtoken")
const dotenv = require("dotenv"); 
// get config vars
dotenv.config();

module.exports={
    checktoken: (req,res,next)=>{
        let token = req.get("authorization");
        if(token){
            token=token.slice(7);
            verify(token,process.env.ACCESS_TOKEN_SECRET,(err,decode)=>{
                if(err){
                    res.json([{ Status: 'Warning', Message: 'Invalid Token or it has been expired.' }])
                }
                else{
                    next();
                }
            })
        }
        else{
            res.json([{ Status: 'Warning', Message: 'Access Denied. Unautherized user.' }])
        }
    }
}
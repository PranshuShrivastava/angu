const Pool = require("pg").Pool;
var fs = require('fs');

const pool = new Pool({
  host: '5eb45698-81b3-4267-aa47-905cc4b87833.a618efcd6c3341158fb843970f0d7edd.databases.appdomain.cloud',
  user: 'psql_adm',
  password: 'Admin12345',
  database: 'bot_db',
  port: '31916', 
  ssl: {
    rejectUnauthorized: false,
    ca: fs.readFileSync('./e0dc3caf-a1f2-11e9-b619-02c049fdd00c.dat').toString()
  },
});

module.exports = pool;